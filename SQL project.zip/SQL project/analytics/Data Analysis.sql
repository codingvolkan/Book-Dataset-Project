
-- Question 1: What is the distribution of ratings for all the books?
/*
Number of responses per rating:
1: 1770
2: 2759
3: 5996
4: 8904
5: 50974
6: 36924
7: 76457
8: 103736
9: 67541
10: 78610

Analyst Comment: There is a peak at 8/10, which implies people don't like to give max ratings, there is also a strange dip at 6/10, there is a jump between 4-5 which then drops back down at 6 which is quite interesting and might warrant further investigation.
*/

-- Code for Question 1:
SELECT 
    Book_Rating,
    COUNT(Book_Rating) AS Book_Ratings
FROM Ratings_cleaned
GROUP BY Book_Rating
ORDER BY Book_Rating ASC;


-- Question 2: What are the top 10 most popular books (by number of ratings)?

/*
1. The Lovely Bones: A Novel by Alice Sebold with 707 ratings
2. Wild Animus by Rich Shapero with 581 ratings
3. The Da Vinci Code by DAN BROWN with 494 ratings
4. The Secret Life of Bees by Sue Monk Kidd with 406 ratings
5. The Nanny Diaries: A Novel by Emma McLaughlin with 393 ratings
6. The Red Tent (Bestselling Backlist) by Anita Diamant with 383 ratings
7. Bridget Jones's Diary by Helen Fielding with 377 ratings
8. A Painted House by John Grisham with 366 ratings
9. Life of Pi by Yann Martel with 336 ratings
10. Girl With a Pearl Earring by Tracy Chevalier with 333 ratings

Analyst Comment: The top 2 books with number of ratings have signifficantly more ratings than the rest of the top 10, which might warrant further analysis. 
*/

-- Code for Question 2: 
SELECT TOP 10
    b.Book_Title,
    b.Book_Author,
    COUNT(r.Book_Rating) AS rating_count
FROM Books_cleaned AS b
LEFT JOIN Ratings_cleaned AS r
    ON b.ISBN = r.ISBN
GROUP BY
    b.Book_Title,
    b.Book_Author
ORDER BY rating_count DESC;


-- Question 3: What top 5 books have the highest average rating (with at least 10 reviews)?
/*
1. Postmarked Yesteryear: 30 Rare Holiday Postcards by Pamela E. Apkarian-Russell has average rating of 10 with 11 votes.
2. Watchmen by Alan Moore has average rating of 9 with 14 votes.
3. CRY THE BELOVED COUNTRY (Scribner Classic) by Alan Paton has average rating of 9 with 11 votes.
4. Roots by Alex Haley has average rating of 9 with 25 votes.
5. The Kalahari Typing School for Men : More from the No. 1 Ladies' Detective Agency by Alexander McCall Smith has average rating of 9 with 13 votes.

Analyst Comment: The first book is the only one with average rating of 10. The fourth book (Roots) has a significant number of votes. 
*/

-- Code for Question 3: 
SELECT TOP 5
    b.Book_Title,
    b.Book_Author,
    AVG(r.Book_Rating) AS average_rating,
    COUNT(r.Book_Rating) AS rating_count
FROM Books_cleaned AS b
LEFT JOIN Ratings_cleaned AS r
    ON b.ISBN = r.ISBN
GROUP BY
    b.Book_Title,
    b.Book_Author
HAVING COUNT(r.Book_Rating) >= 10
ORDER BY average_rating DESC;

-- Question 4: Which age group gives the highest ratings?
/*
90-99 years old people give the highest average rating of 8. This is followed by 60-69 and 30-39 years old people with average rating of 7.
*/

-- Code for Question 4:

WITH GroupedAges AS (
    SELECT
        FLOOR(Age / 10) * 10 AS Age_Group_Start,
        AVG(r.Book_Rating) AS Average_Rating
    FROM Users_cleaned AS u
    LEFT JOIN Ratings_cleaned AS r ON u.User_id = r.User_ID
    WHERE Age BETWEEN 0 AND 100
    GROUP BY FLOOR(Age / 10)
)

SELECT TOP 3
    CONCAT(Age_Group_Start, '-', Age_Group_Start + 9) AS Age_Group,
    Average_Rating
FROM GroupedAges
ORDER BY Average_Rating DESC

-- Question 5: What are the top 10 top-rated books among 20�30 year-olds?

/*
1. Richard Brautigan : A Confederate General from Big Sur, Dreaming of Babylon, and the Hawkline Monster (Three Books in the Manner of Their Original ed) by Richard Brautigan
2. Der Kleine Hobbit by J. R. R. Tolkien
3. Auf Ehre und Gewissen. Roman. by Elizabeth George
4. Im Angesicht des Feindes. by Elizabeth George
5. Mit dem K�?¼hlschrank durch Irland. by Tony Hawks
6. Harry Potter und der Stein der Weisen by Joanne K. Rowling
7. Harry Potter und die Kammer des Schreckens by Joanne K. Rowling
8. Harry Potter und der Gefangene von Azkaban by J. K. Rowling
9. Harry Potter Und Der Feuerkelch by Joanne K. Rowling
10. Die Gefahrten I by J. R. R. Tolkien

Analyst Comment: Majority of the books are German versions and Harry Potter rates highly among this demographic.
*/

-- Code for Question 5: 
SELECT TOP 10
    Book_Title,
    Book_Author,
    Year_Of_Publication,
    Book_Rating
FROM Ratings_cleaned AS r
LEFT JOIN Books_cleaned AS b
    ON b.ISBN = r.ISBN
LEFT JOIN Users_cleaned AS u
    ON r.User_ID = u.User_id
WHERE (u.Age BETWEEN 20 AND 30) AND Book_Title IS NOT NULL
ORDER BY Book_Rating DESC

-- What are the most popular top 5 books in the UK?
/*
1: Bridget Jones's Diary by Helen Fielding with 66 votes.
2: Free by Paul Vincent by Paul Vincent with 46 votes.
3: Chocolat by Joanne Harris Joanne Harris with 42 votes.
4: Wild Animus by Rich Shapero Rich Shapero with 41 votes.
5: Memoirs of a Geisha Uk by Arthur Golden Arthur Golden with 37 votes.
*/

SELECT TOP 5
    b.Book_Title,
    b.Book_Author,
    COUNT(r.Book_Rating) AS rating_count
FROM Ratings_cleaned AS r
INNER JOIN Users_cleaned AS u
    ON r.User_ID = u.User_ID
INNER JOIN Books_cleaned AS b
    ON r.ISBN = b.ISBN
WHERE u.Country = 'united kingdom' OR u.Country = 'england'
GROUP BY b.Book_Title, b.Book_Author
ORDER BY rating_count DESC