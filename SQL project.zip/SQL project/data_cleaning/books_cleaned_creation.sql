/* 
Year of publication contains TEXT (3 records,which have been dropped)
Year of publication is Varchar, can be changed to INT 
Year of publication remove zeros replace with null 
Remove unwanted collumns (Image URLs)
Book Title has records requiring left or right trim (trim)
isbn capitalization is not consistent.
We have duplicate ISBN
We have duplicate book titles, no problem. 
*/

SELECT DISTINCT -- We have duplicate ISBN
	UPPER(ISBN) AS ISBN, -- ISBN capitalization is not consistent.
	TRIM(Book_Title) AS Book_Title, -- Book Title has records requiring left or right trim (trim)
	Book_Author, 
		CAST(
			CASE WHEN Year_Of_Publication = '0' THEN NULL
			ELSE Year_Of_Publication
			END 
		AS INT) AS Year_Of_Publication, --Year of publication is Varchar, can be changed to INT 
	Publisher

INTO Books_cleaned -- New table with clean data

FROM Books -- Original table

WHERE Year_Of_Publication LIKE '%[0-9]%' -- Only selected values where it is numeric to get rid of the non-numeric characters
	AND Book_title != 'Key of Light (Key Trilogy (Paperback))' -- This book has been removed because it was the only duplicate ISBN
