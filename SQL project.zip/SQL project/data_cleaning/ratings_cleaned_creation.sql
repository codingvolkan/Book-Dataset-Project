/*
No NULL user id but data type can be changed to no nulls as it currently accepts nulls
No NULL ISBN but data type can be changed to no nulls as it currently accepts nulls
No empty spaces in ISBN
There are duplicate ISBN but user ID is different. Different users rating the same book. No duplicate ISBN combined with User_ID
*/


-- NULL CHECK
SELECT *
FROM Ratings
WHERE User_ID IS NULL;


SELECT *
FROM Ratings
WHERE ISBN IS NULL;

SELECT *
FROM Ratings
WHERE Book_Rating IS NULL;

-- Duplicate check
SELECT user_id, COUNT(*) AS count
FROM Ratings
GROUP BY user_id
HAVING COUNT(*) > 1;

-- Book_Rating has 0, which is not very realistic as most rating ranges are 1-10, replaced 0 with NULL and create a new table with cleaned data

SELECT
User_ID,
ISBN,
CASE WHEN Book_Rating = 0 THEN NULL
	ELSE Book_Rating
END AS Book_Rating
INTO Ratings_cleaned
FROM Ratings



