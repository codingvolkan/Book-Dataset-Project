/*
Data type Age = Float, change it to INT.
Location has n/a, which can be replaced with NULL.
Age collumn has high values such as 244, which is not plausible. Replaced age values above 100 with NULL.
Location can be broken down into 3 collumns. Those would be city, state and country (these are seperated by commas).
After Location is broken down into 3 collumns, we get empty collumns. These need to be replaced as NULL rather than empty space.
We also have n/a values, which can be replaced as NULL. 
Age has records under 5. I will leave these in for now as it can be handled in the analysis and could potentially be children books
No empty spaces in the begining and the end
No duplicate user id
*/


-- ETC created to divide location column into 3 seperate columns so that we can do more in depth analysis

WITH Extracted AS 
(SELECT
    User_id,
    LTRIM(RTRIM(SUBSTRING(Location, 1, CHARINDEX(',', Location) - 1))) AS City,

    LTRIM(RTRIM(SUBSTRING(Location,CHARINDEX(',', Location) + 1,(LEN(Location) - CHARINDEX(',', REVERSE(Location)) + 1) - CHARINDEX(',', Location) - 1))) AS Region,

    LTRIM(RTRIM(SUBSTRING(Location,LEN(Location) - CHARINDEX(',', REVERSE(Location)) + 2,LEN(Location)))) AS Country,

    Age

FROM Users
WHERE LEN(Location) - LEN(REPLACE(Location, ',', '')) >= 2)

-- Clean 'n/a' values in outer SELECT by using the above ETC
SELECT
    User_id,
    CASE WHEN City LIKE '%n/a%' OR City = ' ' THEN NULL ELSE City END AS City,
    CASE WHEN Region LIKE '%n/a%' OR Region = ' ' THEN NULL ELSE Region END AS Region,
    CASE WHEN Country LIKE '%n/a%' OR Country = ' ' THEN NULL ELSE Country END AS Country,
    CASE WHEN CAST(Age AS INT) > 100 THEN NULL ELSE CAST(Age AS INT) END AS Age
INTO Users_cleaned
FROM Extracted;



